﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class CustomisationGet : MonoBehaviour
{
    [Header("Character Name")]
    public string characterName;
    [Header("Character Class")] // Fill the class
    public CharacterClass characterClass = CharacterClass.Barbarian;
    public string[] selectedClass = new string[8];
    public int selectedClassIndex = 0;

    [System.Serializable] // Make public 
    public struct Stats
    {
        public string BaseClassName; //basestatname in instruction 
        public int baseStats;
        public int Temptstats;
    };
    public Stats[] characterstats; //chacterstats;
  

    [Header("Dropdown Menu")]
    public bool showDropdown;
    public Vector2 scrollPos;
    public string classButton = "";
    public int statPoints = 10;
    [Header("Texture Lists")]
    public List<Texture2D> skin = new List<Texture2D>();
    public List<Texture2D> eyes = new List<Texture2D>();
    public List<Texture2D> hair = new List<Texture2D>();

    public List<Texture2D> mouth = new List<Texture2D>();
    public List<Texture2D> armour = new List<Texture2D>();
    public List<Texture2D> clothes = new List<Texture2D>();
    [Header(" current texture Index")]
    public int skinIndex;
    public int eyesIndex, mouthIndex, hairIndex, armourIndex, clothesIndex;
    [Header("Renderer")]
    public Renderer characterRenderer;
    [Header("Max amount of texture per type")]

    public int skinMax, eyesMax, mouthMax, hairMax, armourMax, clothesMax;
    [Header("Matt Name")]
    public string[] matname = new string[6]; //Statement is declared string to reference 
    public int SelectedClassIndex = 0;


  
    private void Start()
    {
        matname = new string[] { "Skin", "Mouth", "Eyes", "Hair","Armour","Clothes" };
        selectedClass = new string[] { "Barbarian, Bard, Monk, Ranger, Warlock, Sorcerer, Paladin, Druid" }; // Class declared for reference

        for (int i = 0; i < skinMax; i++)
        {
            Texture2D tempTexture = Resources.Load("character/Skin" + i) as Texture2D;
            skin.Add(tempTexture);
        }
        for (int i = 0; i < hairMax; i++)
        {
            Texture2D tempTexture = Resources.Load("character/Hair" + i) as Texture2D;
            hair.Add(tempTexture);
        }
        
        for (int i = 0; i < armourMax; i++)
        {
            Texture2D tempTexture = Resources.Load("character/Armour" + i) as Texture2D;
            armour.Add(tempTexture);
        }
        for (int i = 0; i < eyesMax; i++)
        {
            Texture2D tempTexture = Resources.Load("character/Eyemax" + i) as Texture2D;
            eyes.Add(tempTexture);
        }
        for (int i = 0; i < mouthMax; i++)
        {
            Texture2D tempTexture = Resources.Load("character/mouthMax" + i) as Texture2D;
            mouth.Add(tempTexture);
        }
        for (int i = 0; i < clothesMax; i++)
        {
            Texture2D tempTexture = Resources.Load("character/ClothesMax" + i) as Texture2D;
            clothes.Add(tempTexture);
        }

    }
     void SetTexture(string type, int dir)
    {
        Texture2D[] textures = new Texture2D[0];
        int index = 0, max =0, matindex = 0;


        index += dir;
        if(index <0)
        {
            index = max - 1; 
        }
        if(index > max -1)
        {
            index = 0;
        }
      

        Material[] mat = characterRenderer.materials;
    //    mat[matindex].mainTexture = textures[index];

        characterRenderer.materials = mat;


        switch (type)
        {
            case "Skin":
                index = skinIndex;
                max = skinMax;
                textures = skin.ToArray();
                matindex = 1;
                break;
            case "Eyes":
                index = eyesIndex;
                max = eyesMax;
                textures = eyes.ToArray();
                matindex = 2;
                break;
            case "Mouth":
                index = mouthIndex;
                max = mouthMax;
                textures = mouth.ToArray();
                matindex = 3;
                break;
            case "Armour":
                index = armourIndex;
                max = armourMax;
                textures = armour.ToArray();
                matindex = 4;
                break;
            case "Hair":
                index = hairIndex;
                max = hairMax;
                textures = hair.ToArray();
                matindex = 5;
                break;
            case "Clothes":
                index = clothesIndex;
                max = clothesMax;
                textures = clothes.ToArray();
                matindex = 6;
                break;
        }
         

    }
    void ChooseClass(int classindex)

    { 
        switch (classindex)
        {
            case 0: 
            characterClass = CharacterClass.Barbarian;
                characterstats[0].baseStats = 15;
                characterstats[1].baseStats = 5;
                characterstats[2].baseStats = 8;
                characterstats[3].baseStats = 10;
                characterstats[4].baseStats = 4;
                characterstats[5].baseStats = 5;

                break;
            case 1: // Colon no semi-collon 
                characterClass = CharacterClass.Bard;
                characterstats[0].baseStats = 15;
                characterstats[1].baseStats = 5;
                characterstats[2].baseStats = 5;
                characterstats[3].baseStats = 10;
                characterstats[4].baseStats = 15;
                characterstats[5].baseStats = 15;
                break;
            case 2: 
                characterClass = CharacterClass.Druid;
                characterstats[0].baseStats = 5;
                characterstats[1].baseStats = 8;
                characterstats[2].baseStats = 8;
                characterstats[3].baseStats = 9;
                characterstats[4].baseStats = 15;
                characterstats[5].baseStats = 15;
                break;
            case 3: 
                characterClass = CharacterClass.Ranger;
                characterstats[0].baseStats = 8;
                characterstats[1].baseStats = 15;
                characterstats[2].baseStats = 10;
                characterstats[3].baseStats = 10;
                characterstats[4].baseStats = 15;
                characterstats[5].baseStats = 15;
                break;
            case 4: 
                characterClass = CharacterClass.Warlock;
                characterstats[0].baseStats = 15;
                characterstats[1].baseStats = 15;
                characterstats[2].baseStats = 15;
                characterstats[3].baseStats = 5;
                characterstats[4].baseStats = 10;
                characterstats[5].baseStats = 10;
                break;
            case 5: 
                characterClass = CharacterClass.Sorcerer;
                characterstats[0].baseStats = 15;
                characterstats[1].baseStats = 15;
                characterstats[2].baseStats = 15;
                characterstats[3].baseStats = 15;
                characterstats[4].baseStats = 15;
                characterstats[5].baseStats = 15;
                break;
            case 6: 
                characterClass = CharacterClass.Monk;
                characterstats[0].baseStats = 6;
                characterstats[1].baseStats = 15;
                characterstats[2].baseStats = 15;
                characterstats[3].baseStats = 15;
                characterstats[4].baseStats = 15;
                characterstats[5].baseStats = 15;
                break;
            case 7:  
                characterClass = CharacterClass.Paladin;
                characterstats[0].baseStats = 15;
                characterstats[1].baseStats = 15;
                characterstats[2].baseStats = 10;
                characterstats[3].baseStats = 10;
                characterstats[4].baseStats = 8;
                characterstats[5].baseStats = 10;
                break; 
        }

    }

    void SaveCharacter()
    {
        PlayerPrefs.SetInt("SkinIndex", skinIndex);
        PlayerPrefs.SetInt("HairIndex", hairIndex);
        PlayerPrefs.SetInt("EyesIndex", eyesIndex);
        PlayerPrefs.SetInt("MouthIndex", mouthIndex);
        PlayerPrefs.SetInt("ClothesIndex", clothesIndex);
        PlayerPrefs.SetInt("ArmourIndex", armourIndex);

        PlayerPrefs.SetString("CharacterName", characterName);

        for (int i = 0; i < characterstats.Length; i++)
        {

            PlayerPrefs.SetInt(characterstats[i].BaseClassName, characterstats[i].baseStats +
             characterstats[i].Temptstats);
            PlayerPrefs.SetString("CharacterClass", selectedClass[SelectedClassIndex]);
            //Step 20 Save and Loading using playerpref
        }
        
    }


    private void OnGUI()
    {
        // Shuffle GUI down screen
        #region GUI value setup 

        Vector2 scr = new Vector2(Screen.width / 16, Screen.height / 9);
        //Gui can go down
        //int i = 0;
        //Start Positions 
        float left = 0.25f * scr.x;
        float mid = 0.75f * scr.x;
        float right = 2.25f * scr.x;
        //Sizes 
        float x = 0.5f * scr.x;
        float y = 0.5f * scr.y;
        float lable = 1.5f * scr.x; // Customise Texture Below
        
        #endregion


        #region Customisation Textures
        //button size 
  
        for (int i = 0; i < matname.Length; i++)
        {
            if (GUI.Button(new Rect(left, y + i * y, x+y, y), "<")) // SetTexture[matname].length
            {
                SetTexture(matname[i], +i);
            }
            GUI.Box(new Rect(mid, y * i * y, lable, y), matname[i]); //Gui button 
            if (GUI.Button(new Rect(right, y + i * y, x, y), ">"))
            {
                SetTexture(matname[i], +i);
            }
        }
        #endregion

        #region Choose Class 
        float classX = 12.7f * scr.x;
        float h = 0;
        if(GUI.Button(new Rect(classX,y+h*y, 4*x,y),classButton)) 
        {
            showDropdown = !showDropdown;
   
        }
        h++;
        if (showDropdown)
        { // no arguement
            scrollPos = GUI.BeginScrollView(
                new Rect(classX, y + h * y, 4 * x, 4 * y),scrollPos,
                new Rect(0, 0, 0, selectedClass.Length * y), false, true);

            for (int i = 0; i < selectedClass.Length; i++)
            {
                if(GUI.Button(new Rect(0,i*y,3*x,y), selectedClass[i]))
                {
                    ChooseClass(i);
                    classButton = selectedClass[i];
                    showDropdown = false;
                }
            }
            GUI.EndScrollView();
        }

        #endregion //Math is corrected. The button is small calculate of math rect tool

        #region Choose stats
        GUI.Box(new Rect(classX, 7 * y, 4*x, y), "Points; " + statPoints);
        for (int i = 0; i < characterstats.Length; i++)
        {
            if(statPoints > 0)
            {
                //-
                if(GUI.Button(new Rect(classX-x, 7 *y, 1 * y, 4 * x),"+"))
                {
                    statPoints--;
                    characterstats[i].Temptstats++;
                }
                 
            }
            GUI.Box(new Rect(classX, 7 * y + 1 * y, 4 * x, y), characterstats[i].BaseClassName + ":" + (characterstats[i].baseStats 
                + characterstats[i].Temptstats));
            if (statPoints < 10 && characterstats[i].Temptstats > 0)
            {
                //+
                if(GUI.Button(new Rect(classX + x, 7 * y, 1 * y, 4 * x), "-"))
                {
                    statPoints++;
                    characterstats[i].Temptstats--;
                }
            } 
        }

        characterName = GUI.TextField(new Rect(left, 8 * y, 5 * x, y), characterName, 32);
        if (GUI.Button(new Rect(), "Save and Play"))
        {
            SaveCharacter();
            SceneManager.LoadScene(2);
        }

        #endregion

        #region Set Stats
        // Same Code as Choose Stats
        /*  
          GUI.Box(new Rect(classX, 5 * y, 4 * x, y), "Points: " + statPoints);
            for (int i = 0; i < characterstats.Length; i++)
            {
              if(statPoints > 0)
              {
                  //+ button
                  if(GUI.Button(new Rect(),"+"))
                  {
                      statPoints--;
                      characterstats[i].Temptstats++;
                  }
              }

              GUI.Box(new Rect(classX, 7 * y, 4 * x, y), characterstats[i].BaseClassName
                  + ":" + (characterstats[i].baseStats+characterstats[i].Temptstats));

              if(statPoints < 10 && characterstats[i].Temptstats >0)
              {
                  // - button
                  if(GUI.Button(new Rect(), "-"))
                  {
                      statPoints++;
                      characterstats[i].Temptstats--;
                  }
              }
            }*/


        #endregion
    }
}


public enum CharacterClass
{
    Barbarian, 
    Bard, 
    Monk, 
    Ranger,
    Warlock, 
    Sorcerer, 
    Paladin, 
    Druid
}