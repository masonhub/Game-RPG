﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CustomisationSet : MonoBehaviour
{
    public Renderer characterRenderer;
    public GameObject player; 
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        Load();   
    }

    // Update is called once per frame
    void Load()
    {

       
        SetTexture("Skin", PlayerPrefs.GetInt("SkinIndex"));
        SetTexture("Eyes", PlayerPrefs.GetInt("SkinIndex"));
        SetTexture("Mouth", PlayerPrefs.GetInt("SkinIndex"));
        SetTexture("Armour", PlayerPrefs.GetInt("SkinIndex"));
        SetTexture("Hair", PlayerPrefs.GetInt("SkinIndex"));
        SetTexture("Clothes", PlayerPrefs.GetInt("SkinIndex"));
    }

    void SetTexture(string type, int index)
    {
        Texture2D texture = null;
        int matindex = 0;
        switch (type)
        {
            case "Skin":
                texture = Resources.Load("character/Skin_" + index) as Texture2D;
                    matindex = 1;
                break;
            case "Eyes":
                texture = Resources.Load("character/eye_" + index) as Texture2D;
                    matindex = 2;
                break;
            case "Mouth":
                texture = Resources.Load("character/eye_" + index) as Texture2D;
                    matindex = 3;
                break;
            case "Hair":
                texture = Resources.Load("character/eye_" + index) as Texture2D;
                    matindex = 4;
                break;
            case "Clothes":
                texture = Resources.Load("character/eye_" + index) as Texture2D;
                    matindex = 5;
                break;
            case "Armour":
                texture = Resources.Load("character/eye_" + index) as Texture2D;
                    matindex = 6;
                break;
        }
        Material[] mats = characterRenderer.materials;
        mats[matindex].mainTexture = texture;
        characterRenderer.materials = null;
        

    }
}
